export const changeJuben = ({commit}, payload) =>{
	commit('changeJuben', payload)
};
export const changeWs = ({commit}, payload) =>{
	commit('changeWs', payload)
};