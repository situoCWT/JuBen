export const changeJuben = (state,juben) =>{
	state.juben = juben;
}
export const changeWs = (state,ws) =>{
	state.ws = ws;
}